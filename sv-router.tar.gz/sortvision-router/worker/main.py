"""Worker main loop — BLPOP z Redis, OCR per strona, HSET wynik."""

from __future__ import annotations

import asyncio
import json
import logging
import signal
import time

import redis.asyncio as aioredis

from worker.config import worker_settings
from worker.ocr_engine import ollama_ocr

# ── Logging ────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [WORKER:%(name)s] %(message)s",
)
logger = logging.getLogger(worker_settings.worker_name)

# ── Graceful shutdown ──────────────────────────────────────────────
_shutdown_event = asyncio.Event()

_RECONNECT_BASE_DELAY = 1.0
_RECONNECT_MAX_DELAY = 30.0
_JOB_TTL = 3600
_EWT_WINDOW = 20


def _handle_signal(sig: signal.Signals) -> None:
    """Ustaw flagę shutdown — worker dokończy aktualny job."""
    logger.info("Otrzymano sygnał %s — kończę po aktualnym jobie...", sig.name)
    _shutdown_event.set()


# ══════════════════════════════════════════════════════════════════
#  WorkerRedis — lekki wrapper kompatybilny z gateway RedisClient
# ══════════════════════════════════════════════════════════════════


class WorkerRedis:
    """Wrapper aioredis z metodami kompatybilnymi z gateway.redis_client."""

    def __init__(self, pool: aioredis.Redis) -> None:
        self._pool = pool

    @property
    def pool(self) -> aioredis.Redis:
        return self._pool

    async def set_job_status(
        self,
        job_id: str,
        status: str,
        *,
        progress: str | None = None,
        extra: dict | None = None,
    ) -> None:
        """HSET status + opcjonalne pola do hasha job:{job_id}."""
        key = f"job:{job_id}"
        mapping: dict[str, str] = {
            "status": status,
            "updated_at": str(time.time()),
        }
        if progress is not None:
            mapping["progress"] = progress
        if extra:
            mapping.update({k: str(v) for k, v in extra.items()})

        pipe = self._pool.pipeline(transaction=False)
        pipe.hset(key, mapping=mapping)
        pipe.expire(key, _JOB_TTL)
        await pipe.execute()

    async def is_cancelled(self, job_id: str) -> bool:
        """EXISTS cancelled:{job_id}."""
        return bool(await self._pool.exists(f"cancelled:{job_id}"))

    async def set_job_result(
        self,
        job_id: str,
        text: str,
        source: str,
        processing_time_ms: int,
        *,
        status: str = "completed",
    ) -> None:
        """Zapisz wynik: HSET + EXPIRE + PUBLISH + LPUSH recent + SREM active."""
        key = f"job:{job_id}"
        mapping: dict[str, str] = {
            "status": status,
            "text": text,
            "source": source,
            "processing_time_ms": str(processing_time_ms),
            "updated_at": str(time.time()),
            "progress": "",
        }
        pipe = self._pool.pipeline(transaction=False)
        pipe.hset(key, mapping=mapping)
        pipe.expire(key, _JOB_TTL)
        pipe.publish(f"result_channel:{job_id}", status)
        pipe.lpush("recent_jobs", job_id)
        pipe.ltrim("recent_jobs", 0, 99)
        pipe.srem("active_jobs", job_id)
        await pipe.execute()

    async def remove_active_job(self, job_id: str) -> None:
        """SREM active_jobs."""
        await self._pool.srem("active_jobs", job_id)

    async def record_processing_time(self, worker_name: str, time_ms: int) -> None:
        """LPUSH + LTRIM metryki do moving-average window."""
        key = f"metrics:{worker_name}"
        pipe = self._pool.pipeline(transaction=False)
        pipe.lpush(key, str(time_ms))
        pipe.ltrim(key, 0, _EWT_WINDOW - 1)
        await pipe.execute()


# ══════════════════════════════════════════════════════════════════
#  Podłączenie Redis z reconnect
# ══════════════════════════════════════════════════════════════════


async def _connect_redis() -> WorkerRedis:
    """Połącz z Redis z exponential backoff przy błędach."""
    delay = _RECONNECT_BASE_DELAY
    while not _shutdown_event.is_set():
        try:
            pool = aioredis.from_url(
                worker_settings.redis_url,
                decode_responses=True,
                max_connections=4,
            )
            await pool.ping()
            logger.info("Redis połączony: %s", worker_settings.redis_url)
            return WorkerRedis(pool)
        except Exception as exc:
            logger.error(
                "Redis niedostępny: %s — retry za %.0fs", exc, delay
            )
            await asyncio.sleep(delay)
            delay = min(delay * 2, _RECONNECT_MAX_DELAY)

    raise SystemExit("Shutdown podczas łączenia z Redis")


# ══════════════════════════════════════════════════════════════════
#  Przetwarzanie pojedynczego joba
# ══════════════════════════════════════════════════════════════════


async def _process_job(
    redis: WorkerRedis, queue_name: str, raw_payload: str
) -> None:
    """Przetwórz pojedynczy job z kolejki — per strona z progress."""
    name = worker_settings.worker_name

    # 1. Deserializuj payload
    try:
        job = json.loads(raw_payload)
    except json.JSONDecodeError:
        logger.error("[WORKER:%s] Nieprawidłowy JSON w kolejce — pomijam", name)
        return

    job_id: str = job.get("job_id", "unknown")

    # 2. Sprawdź cancelled (watchdog mógł już obsłużyć timeout)
    if await redis.is_cancelled(job_id):
        logger.info("[WORKER:%s] Job %s anulowany, skip", name, job_id)
        return

    # 3. doc_base64 BEZPOŚREDNIO z payloadu kolejki (NIE z dysku!)
    raw_doc = job.get("doc_base64")
    if not raw_doc:
        logger.error(
            "[WORKER:%s] [JOB:%s] brak doc_base64 w payloadzie — fail",
            name, job_id,
        )
        await redis.set_job_status(
            job_id, "failed", extra={"text": "Brak doc_base64 w payloadzie"}
        )
        await redis.remove_active_job(job_id)
        return

    # 4. WALIDACJA STRON — nie ufaj klientowi!
    pages_data: list[str] = raw_doc if isinstance(raw_doc, list) else [raw_doc]
    actual_pages = len(pages_data)  # PRAWDA, nie job.pages

    filename = job.get("filename", "?")
    width = job.get("width", 0)
    height = job.get("height", 0)

    logger.info(
        "[WORKER:%s] [JOB:%s] START — queue=%s, pages=%d, res=%dx%d, file=%s",
        name, job_id, queue_name, actual_pages, width, height, filename,
    )

    # 5. Oznacz jako processing
    await redis.set_job_status(
        job_id, "processing", progress=f"strona 0/{actual_pages}"
    )

    # 6. OCR per strona — for/else z cancel check
    start = time.monotonic()
    all_text: list[str] = []

    try:
        for i, page_img in enumerate(pages_data):
            # Sprawdź cancelled MIĘDZY stronami (watchdog mógł anulować!)
            if await redis.is_cancelled(job_id):
                logger.info("[WORKER:%s] Job %s anulowany, skip", name, job_id)
                break

            page_text = await ollama_ocr.process(page_img)
            all_text.append(page_text)
            await redis.set_job_status(
                job_id, "processing", progress=f"strona {i + 1}/{actual_pages}"
            )

        else:
            # for/else: wszystkie strony OK
            final_text = "\n\n".join(all_text)
            elapsed_ms = int((time.monotonic() - start) * 1000)

            await redis.set_job_result(job_id, final_text, name, elapsed_ms)
            await redis.record_processing_time(name, elapsed_ms)

            # 7. Log
            logger.info(
                "[WORKER:%s] [JOB:%s] %d stron, %dms, %d znaków",
                name, job_id, actual_pages, elapsed_ms, len(final_text),
            )

    except Exception as exc:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        logger.error(
            "[WORKER:%s] [JOB:%s] FAILED po %dms: %s",
            name, job_id, elapsed_ms, exc,
        )
        await redis.set_job_status(
            job_id, "failed", extra={"text": f"OCR error: {exc}"}
        )
        await redis.remove_active_job(job_id)


# ══════════════════════════════════════════════════════════════════
#  Główna pętla workera
# ══════════════════════════════════════════════════════════════════


async def _worker_loop() -> None:
    """Główna pętla: BLPOP → process → repeat."""
    redis = await _connect_redis()
    queues = worker_settings.queues
    name = worker_settings.worker_name

    logger.info(
        "Worker '%s' uruchomiony — kolejki=%s, ollama=%s/%s",
        name,
        queues,
        worker_settings.ollama_url,
        worker_settings.ollama_model,
    )

    try:
        while not _shutdown_event.is_set():
            try:
                # BLPOP z timeout 1s — pozwala sprawdzać flagę shutdown
                result = await redis.pool.blpop(queues, timeout=1)
                if result is None:
                    continue

                queue_name, raw_payload = result
                await _process_job(redis, queue_name, raw_payload)

            except (aioredis.ConnectionError, aioredis.TimeoutError, OSError) as exc:
                logger.error("Redis rozłączony: %s — reconnect...", exc)
                try:
                    await redis.pool.aclose()
                except Exception:
                    pass
                redis = await _connect_redis()

    finally:
        await ollama_ocr.close()
        await redis.pool.aclose()
        logger.info("Worker '%s' zakończony", name)


# ══════════════════════════════════════════════════════════════════
#  Entrypoint: python -m worker.main
# ══════════════════════════════════════════════════════════════════


def main() -> None:
    """Uruchom worker loop z obsługą sygnałów."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _handle_signal, sig)
        except NotImplementedError:
            # Windows nie wspiera add_signal_handler — użyj signal.signal
            signal.signal(sig, lambda s, _f: _handle_signal(signal.Signals(s)))

    try:
        loop.run_until_complete(_worker_loop())
    finally:
        loop.close()


if __name__ == "__main__":
    main()
