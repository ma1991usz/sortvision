"""Konfiguracja workera — ładowana z env vars z prefixem SV_WORKER_."""

from pydantic_settings import BaseSettings


class WorkerSettings(BaseSettings):
    """Ustawienia workera SortVision OCR."""

    # ── Identyfikacja ─────────────────────────────────────────────
    worker_name: str = "tesla_p4"
    """Nazwa workera — 'tesla_p4' lub 'rtx_3060'."""

    # ── Redis ─────────────────────────────────────────────────────
    redis_url: str = "redis://localhost:6379/0"

    # ── Kolejki do nasłuchiwania (BLPOP) ─────────────────────────
    queues: list[str] = ["queue:tesla_p4"]
    """Lista kolejek w kolejności priorytetu.
    RTX 3060: ["queue:rtx_3060", "queue:tesla_p4"] — Queue Stealing!
    Tesla P4: ["queue:tesla_p4"] — tylko lekkie joby."""

    # ── Ollama ────────────────────────────────────────────────────
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "glm-ocr:latest"

    model_config = {"env_prefix": "SV_WORKER_"}


worker_settings = WorkerSettings()
