"""Test routing: duzy obraz (>3MP) powinien pojsc na RTX 3060."""
import base64
import json
import sys
import time
import urllib.request
from io import BytesIO
from PIL import Image, ImageDraw

# Obraz 2000x2000 = 4MP > 3MP limit P4 -> powinien isc na RTX 3060
img = Image.new("RGB", (2000, 2000), "white")
draw = ImageDraw.Draw(img)
draw.text((50, 50), "Duzy obraz routing test", fill="black")
draw.text((50, 100), "Faktura VAT nr 123/2026", fill="black")
draw.text((50, 150), "Kwota: 1234.56 PLN", fill="black")
buf = BytesIO()
img.save(buf, format="JPEG", quality=85)
b64 = base64.b64encode(buf.getvalue()).decode()
print(f"[1] Duzy obraz: {len(b64)} bajtow base64, 2000x2000 = 4MP")

payload = json.dumps({"doc_base64": b64, "pages": 1, "width": 2000, "height": 2000})
req = urllib.request.Request(
    "http://127.0.0.1:8015/api/v1/ocr",
    data=payload.encode(),
    headers={"Content-Type": "application/json"},
)
resp = urllib.request.urlopen(req, timeout=10)
result = json.loads(resp.read())
job_id = result["job_id"]
routed = result.get("routed_to", "?")
print(f"[2] Job: {job_id}, routed_to={routed}")

deadline = time.time() + 120
while time.time() < deadline:
    time.sleep(3)
    req2 = urllib.request.Request(f"http://127.0.0.1:8015/api/v1/ocr/{job_id}")
    resp2 = urllib.request.urlopen(req2, timeout=10)
    data = json.loads(resp2.read())
    status = data.get("status")
    print(f"   poll: status={status}, progress={data.get('progress','')}")
    if status == "completed":
        print(f"[3] SUKCES! source={data.get('source')}, time={data.get('processing_time_ms')}ms")
        print(f"    TEXT: {data.get('text', '')[:200]}")
        sys.exit(0)
    elif status == "failed":
        print(f"[3] FAILED: {data.get('text', '?')}")
        sys.exit(1)

print("[3] TIMEOUT!")
sys.exit(1)
