"""Testowy skrypt: generuje obraz z tekstem i wysyla do gateway OCR."""
import base64
import json
import subprocess
import sys
import time
from io import BytesIO
from PIL import Image, ImageDraw

# 1. Stworz obraz z tekstem
img = Image.new("RGB", (400, 100), "white")
draw = ImageDraw.Draw(img)
draw.text((20, 30), "Test OCR 123 abc", fill="black")
buf = BytesIO()
img.save(buf, format="JPEG", quality=85)
b64 = base64.b64encode(buf.getvalue()).decode()
print(f"[1] Obraz testowy: {len(b64)} bajtow base64")

# 2. Wyslij do gateway
payload = json.dumps({"doc_base64": b64, "pages": 1, "width": 400, "height": 100})
with open("/tmp/ocr_payload.json", "w") as f:
    f.write(payload)

import urllib.request
req = urllib.request.Request(
    "http://127.0.0.1:8015/api/v1/ocr",
    data=payload.encode(),
    headers={"Content-Type": "application/json"},
)
resp = urllib.request.urlopen(req, timeout=10)
result = json.loads(resp.read())
job_id = result["job_id"]
timeout_s = result["timeout_seconds"]
poll_s = result.get("poll_interval", 2)
print(f"[2] Job submitted: {job_id}, timeout={timeout_s}s, poll={poll_s}s")

# 3. Poll
deadline = time.time() + timeout_s + 10
while time.time() < deadline:
    time.sleep(poll_s)
    req2 = urllib.request.Request(f"http://127.0.0.1:8015/api/v1/ocr/{job_id}")
    resp2 = urllib.request.urlopen(req2, timeout=10)
    data = json.loads(resp2.read())
    status = data.get("status")
    print(f"   poll: status={status}, progress={data.get('progress','')}")
    if status == "completed":
        print(f"[3] SUKCES! source={data.get('source')}, time={data.get('processing_time_ms')}ms")
        print(f"    TEXT: {data.get('text', '')[:200]}")
        sys.exit(0)
    elif status == "failed":
        print(f"[3] FAILED: {data.get('text', '?')}")
        sys.exit(1)

print("[3] TIMEOUT!")
sys.exit(1)
