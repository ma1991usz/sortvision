"""Inteligentny router OCR — przydziela joby do kolejek GPU + dynamiczny timeout."""

from __future__ import annotations

import logging

from gateway.config import settings
from gateway.redis_client import QUEUE_RTX_3060, QUEUE_TESLA_P4, redis_client

logger = logging.getLogger(__name__)


class OCRRouter:
    """Decyduje do której kolejki GPU trafia job.

    Reguły:
    1. Ciężkie joby (>MAX_PAGES_P4 stron lub >MAX_RESOLUTION_P4 px)
       → RTX 3060 (HARD LIMIT — P4 NIGDY ich nie dostaje).
    2. Lekkie joby → kandydat to Tesla P4.
    3. Ale jeśli EWT kandydata > 2× EWT drugiej kolejki
       I job NIE za ciężki dla P4 → przekieruj.
    4. HARD LIMIT: P4 NIGDY nie dostaje > 2 stron lub > 3MP,
       nawet jeśli EWT niższe.
    """

    async def decide(self, pages: int, width: int, height: int) -> str:
        """Wybierz kolejkę dla joba.

        Returns:
            Nazwa kolejki Redis (np. "queue:tesla_p4").
        """
        resolution = width * height
        is_heavy = (
            pages > settings.max_pages_p4
            or resolution > settings.max_resolution_p4
        )

        # ── Hard limit: P4 NIGDY nie dostaje ciężkich jobów ───────
        if is_heavy:
            logger.info(
                "Router → RTX 3060 (hard limit): pages=%d, res=%d "
                "(limit pages=%d, res=%d)",
                pages,
                resolution,
                settings.max_pages_p4,
                settings.max_resolution_p4,
            )
            return QUEUE_RTX_3060

        # ── Lekki job — kandydat to P4, ale sprawdź EWT ──────────
        ewt_p4 = await self._estimate_wait(QUEUE_TESLA_P4)
        ewt_3060 = await self._estimate_wait(QUEUE_RTX_3060)

        # Przekieruj na 3060 jeśli P4 jest >2× bardziej obciążone
        if ewt_3060 > 0 and ewt_p4 > 2 * ewt_3060:
            logger.info(
                "Router → RTX 3060 (EWT rebalance): "
                "ewt_p4=%.1fs > 2×ewt_3060=%.1fs, pages=%d, res=%d",
                ewt_p4,
                ewt_3060,
                pages,
                resolution,
            )
            return QUEUE_RTX_3060

        logger.info(
            "Router → Tesla P4: pages=%d, res=%d, ewt_p4=%.1fs, ewt_3060=%.1fs",
            pages,
            resolution,
            ewt_p4,
            ewt_3060,
        )
        return QUEUE_TESLA_P4

    async def _estimate_wait(self, queue_name: str) -> float:
        """EWT (Estimated Wait Time) = queue_length × avg_time_s."""
        length = await redis_client.get_queue_length(queue_name)
        worker_key = queue_name.removeprefix("queue:")
        avg_ms = await redis_client.get_avg_processing_time(worker_key)
        if avg_ms <= 0 or length == 0:
            return 0.0
        return (length * avg_ms) / 1000.0

    @staticmethod
    def calculate_timeout(pages: int) -> int:
        """Dynamiczny timeout dla joba.

        Formuła: BASE_TIMEOUT + pages × PER_PAGE_TIMEOUT
        Przykłady: 1s=45s, 2s=70s, 10s=270s, 20s=520s
        """
        return settings.base_timeout_seconds + pages * settings.per_page_timeout_seconds


# ── Globalny singleton ─────────────────────────────────────────────
ocr_router = OCRRouter()
