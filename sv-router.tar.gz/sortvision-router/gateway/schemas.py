"""Modele Pydantic v2 — kontrakty API i wewnętrzne payloady."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


# ── Request API ────────────────────────────────────────────────────


class OCRRequest(BaseModel):
    """Żądanie OCR od klienta (gateway)."""

    doc_base64: str | list[str] = Field(
        ..., description="Base64 jednej strony (str) lub lista base64 per strona"
    )
    pages: int = Field(..., ge=1, description="Liczba stron dokumentu")
    width: int = Field(..., gt=0, description="Szerokość obrazu w px")
    height: int = Field(..., gt=0, description="Wysokość obrazu w px")
    filename: str | None = Field(None, description="Oryginalna nazwa pliku")


# ── Response: submit (HTTP 202) ────────────────────────────────────


class OCRSubmitResponse(BaseModel):
    """Natychmiastowa odpowiedź po POST /ocr (HTTP 202)."""

    job_id: str
    status: Literal["queued"]
    queue: str = Field(..., description='Kolejka GPU: "tesla_p4" lub "rtx_3060"')
    timeout_seconds: int = Field(..., description="Dynamiczny timeout dla tego joba")
    poll_interval: int = Field(..., description="Co ile sekund pollować (sugerowane)")
    poll_url: str = Field(..., description="URL do pollowania: /api/v1/ocr/{job_id}")


# ── Response: polling status ───────────────────────────────────────


class OCRStatusResponse(BaseModel):
    """Odpowiedź na GET /api/v1/ocr/{job_id} — klient polluje co 3s."""

    job_id: str
    status: Literal["queued", "processing", "completed", "failed", "fallback"]
    progress: str | None = None
    text: str | None = None
    source: Literal["tesla_p4", "rtx_3060", "openai"] | None = None
    processing_time_ms: int | None = None
    created_at: float
    updated_at: float


# ── Wewnętrzny payload kolejki Redis ───────────────────────────────


class JobPayload(BaseModel):
    """Payload wrzucany do kolejki Redis (RPUSH).

    UWAGA: zawiera doc_base64 — trafia do kolejki (RPUSH),
    ale NIGDY nie jest zapisywany w hashu job:{job_id}.
    """

    job_id: str
    pages: int
    width: int
    height: int
    doc_base64: str | list[str] = Field(
        ..., description="Base64 obrazów — idzie do kolejki, NIE do hasha"
    )
    filename: str | None = None
    created_at: float = Field(..., description="time.time() momentu utworzenia")
    timeout_at: float = Field(..., description="Kiedy watchdog ma odpalić fallback")


# ── Statystyki kolejki ─────────────────────────────────────────────


class QueueStats(BaseModel):
    """Statystyki kolejki — używane przez /status i dashboard."""

    queue_name: str
    length: int
    ewt_seconds: float
    active_jobs: int
