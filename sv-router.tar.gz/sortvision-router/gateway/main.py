"""SortVision OCR Router — Gateway (FastAPI, Async Worker Pull Pattern)."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

import aiofiles
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from gateway.config import settings
from gateway.fallback import openai_fallback
from gateway.redis_client import (
    QUEUE_RTX_3060,
    QUEUE_TESLA_P4,
    redis_client,
)
from gateway.router import ocr_router
from gateway.schemas import (
    JobPayload,
    OCRRequest,
    OCRStatusResponse,
    OCRSubmitResponse,
)
from gateway.watchdog import Watchdog

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("gateway")

# ── Globalny httpx do healthchecków Ollama ─────────────────────────
_http: httpx.AsyncClient | None = None
_start_time: float = 0.0
_watchdog: Watchdog | None = None
_watchdog_task: asyncio.Task | None = None

# ── Licznik jobów per source (ostatnia minuta) ────────────────────
_job_counter: dict[str, list[float]] = {
    "tesla_p4": [],
    "rtx_3060": [],
    "openai": [],
}


def _count_job(source: str) -> None:
    """Zanotuj timestamp joba dla danego source."""
    _job_counter.setdefault(source, []).append(time.time())


def _jobs_last_minute(source: str) -> int:
    """Policz joby z ostatnich 60 sekund."""
    now = time.time()
    lst = _job_counter.get(source, [])
    fresh = [t for t in lst if now - t < 60]
    _job_counter[source] = fresh
    return len(fresh)


# ══════════════════════════════════════════════════════════════════
#  Lifespan
# ══════════════════════════════════════════════════════════════════


@asynccontextmanager
async def lifespan(_app: FastAPI):  # noqa: ANN201
    """Startup / shutdown lifecycle."""
    global _http, _start_time, _watchdog, _watchdog_task

    _start_time = time.time()

    # Katalog na pliki base64 (backup dla watchdoga)
    os.makedirs(settings.jobs_disk_path, exist_ok=True)

    # Redis connection pool
    await redis_client.connect()

    # httpx do healthchecków Ollama
    _http = httpx.AsyncClient(timeout=httpx.Timeout(5.0, connect=3.0))

    # Watchdog — background task skanujący timeouty
    _watchdog = Watchdog(redis_client, openai_fallback, settings)
    _watchdog_task = asyncio.create_task(_watchdog.run())

    logger.info(
        "Gateway uruchomiony — Redis=%s, P4=%s, 3060=%s, "
        "base_timeout=%ds, per_page=%ds",
        settings.redis_url,
        settings.tesla_p4_url,
        settings.rtx_3060_url,
        settings.base_timeout_seconds,
        settings.per_page_timeout_seconds,
    )

    yield

    # Shutdown
    if _watchdog is not None:
        _watchdog.stop()
    if _watchdog_task is not None:
        _watchdog_task.cancel()
        try:
            await _watchdog_task
        except asyncio.CancelledError:
            pass

    await openai_fallback.close()
    if _http is not None:
        await _http.aclose()
    await redis_client.close()
    logger.info("Gateway zamknięty")


# ══════════════════════════════════════════════════════════════════
#  App + Middleware
# ══════════════════════════════════════════════════════════════════

app = FastAPI(
    title="SortVision OCR Router",
    version="3.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def timing_middleware(request: Request, call_next):  # noqa: ANN001, ANN201
    """Dodaj X-Process-Time header do każdej odpowiedzi."""
    t0 = time.monotonic()
    response = await call_next(request)
    elapsed = time.monotonic() - t0
    response.headers["X-Process-Time"] = f"{elapsed:.3f}"
    return response


@app.exception_handler(Exception)
async def global_error_handler(_request: Request, exc: Exception) -> JSONResponse:
    """Zawsze zwracaj JSON, nigdy HTML."""
    logger.exception("Nieobsłużony błąd: %s", exc)
    return JSONResponse(
        status_code=500,
        content={"detail": str(exc)},
    )


# ══════════════════════════════════════════════════════════════════
#  POST /api/v1/ocr — submit (HTTP 202, natychmiast)
# ══════════════════════════════════════════════════════════════════


@app.post("/api/v1/ocr", response_model=OCRSubmitResponse, status_code=202)
async def ocr_submit(req: OCRRequest) -> OCRSubmitResponse:
    """Przyjmij dokument → zapisz na dysk → kolejka → HTTP 202.

    Gateway NIGDY nie blokuje na GPU. Klient polluje GET /api/v1/ocr/{job_id}.
    """
    job_id = uuid.uuid4().hex
    now = time.time()

    # 1. Normalizuj doc_base64 do listy
    images: list[str] = (
        req.doc_base64 if isinstance(req.doc_base64, list) else [req.doc_base64]
    )
    actual_pages = len(images)

    # 2. Router decyduje o kolejce + timeout
    queue = await ocr_router.decide(actual_pages, req.width, req.height)
    timeout_s = ocr_router.calculate_timeout(actual_pages)
    timeout_at = now + timeout_s

    # 3. Zapisz base64 na dysk (backup dla watchdoga — NIGDY do Redis!)
    os.makedirs(settings.jobs_disk_path, exist_ok=True)
    doc_path = os.path.join(settings.jobs_disk_path, f"{job_id}.b64")
    async with aiofiles.open(doc_path, "w") as f:
        if isinstance(req.doc_base64, list):
            await f.write(json.dumps(req.doc_base64))
        else:
            await f.write(req.doc_base64)

    # 4. Zbuduj payload z doc_base64 (trafia do kolejki, NIE do hasha)
    payload = JobPayload(
        job_id=job_id,
        pages=actual_pages,
        width=req.width,
        height=req.height,
        doc_base64=req.doc_base64,
        filename=req.filename,
        created_at=now,
        timeout_at=timeout_at,
    )

    # 5. RPUSH payload do kolejki
    await redis_client.push_job(queue, payload.model_dump_json())

    # 6. HSET status w hashu job:{job_id} (BEZ doc_base64!)
    await redis_client.set_job_status(
        job_id,
        "queued",
        extra={
            "queue": queue,
            "created_at": now,
            "timeout_at": timeout_at,
            "doc_path": doc_path,
            "pages": actual_pages,
            "width": req.width,
            "height": req.height,
            "filename": req.filename or "",
        },
    )

    # 7. SADD do active_jobs set
    await redis_client.add_active_job(job_id)

    logger.info(
        "Job %s → %s (pages=%d, res=%dx%d, timeout=%ds)",
        job_id, queue, actual_pages, req.width, req.height, timeout_s,
    )
    _count_job("tesla_p4" if queue == QUEUE_TESLA_P4 else "rtx_3060")

    return OCRSubmitResponse(
        job_id=job_id,
        status="queued",
        queue=queue,
        timeout_seconds=timeout_s,
        poll_interval=settings.job_poll_interval_hint,
        poll_url=f"/api/v1/ocr/{job_id}",
    )


# ══════════════════════════════════════════════════════════════════
#  GET /api/v1/ocr/{job_id} — polling statusu
# ══════════════════════════════════════════════════════════════════


@app.get("/api/v1/ocr/{job_id}", response_model=OCRStatusResponse)
async def ocr_poll(job_id: str) -> OCRStatusResponse:
    """Pobierz aktualny status joba — klient polluje co poll_interval sekund."""
    data = await redis_client.get_job_status(job_id)

    if not data:
        raise HTTPException(status_code=404, detail=f"Job {job_id} nie znaleziony")

    # Zmapuj pola z Redis hash na model (NIE zwracaj doc_path ani doc_base64!)
    source_raw = data.get("source", "")
    time_raw = data.get("processing_time_ms", "")

    return OCRStatusResponse(
        job_id=job_id,
        status=data.get("status", "queued"),
        progress=data.get("progress") or None,
        text=data.get("text") or None,
        source=source_raw if source_raw else None,
        processing_time_ms=int(time_raw) if time_raw else None,
        created_at=float(data.get("created_at", 0)),
        updated_at=float(data.get("updated_at", 0)),
    )


# ══════════════════════════════════════════════════════════════════
#  POST /api/v1/ocr/sync — bezpośrednio do Ollama (debug)
# ══════════════════════════════════════════════════════════════════


@app.post("/api/v1/ocr/sync", response_model=OCRStatusResponse)
async def ocr_sync(req: OCRRequest) -> OCRStatusResponse:
    """Tryb synchroniczny — odpytuje Ollama bezpośrednio (bez kolejki)."""
    t0 = time.monotonic()
    now = time.time()
    job_id = uuid.uuid4().hex

    images: list[str] = (
        req.doc_base64 if isinstance(req.doc_base64, list) else [req.doc_base64]
    )

    queue = await ocr_router.decide(len(images), req.width, req.height)
    ollama_url = (
        settings.tesla_p4_url if queue == QUEUE_TESLA_P4 else settings.rtx_3060_url
    )
    source = "tesla_p4" if queue == QUEUE_TESLA_P4 else "rtx_3060"

    logger.info("Sync OCR %s → %s", job_id, ollama_url)

    try:
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(90.0, connect=5.0)
        ) as client:
            all_texts: list[str] = []
            for img in images:
                resp = await client.post(
                    f"{ollama_url}/api/chat",
                    json={
                        "model": "glm-ocr:latest",
                        "stream": False,
                        "messages": [
                            {
                                "role": "user",
                                "content": "Przepisz cały tekst z tego dokumentu.",
                                "images": [img],
                            }
                        ],
                    },
                )
                resp.raise_for_status()
                resp_data = resp.json()
                all_texts.append(
                    resp_data.get("message", {}).get("content", "")
                )

        text = "\n\n".join(all_texts)
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        _count_job(source)
        return OCRStatusResponse(
            job_id=job_id,
            status="completed",
            text=text,
            source=source,
            processing_time_ms=elapsed_ms,
            created_at=now,
            updated_at=time.time(),
        )
    except Exception as exc:
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        logger.error("Sync OCR error: %s", exc)
        return OCRStatusResponse(
            job_id=job_id,
            status="failed",
            text=f"Sync OCR error: {exc}",
            processing_time_ms=elapsed_ms,
            created_at=now,
            updated_at=time.time(),
        )


# ══════════════════════════════════════════════════════════════════
#  GET /api/v1/status — dashboard JSON
# ══════════════════════════════════════════════════════════════════


@app.get("/api/v1/status")
async def status_endpoint() -> dict[str, Any]:
    """Dashboard ze statystykami kolejek i workerów."""
    queue_stats = await redis_client.get_all_queue_stats()

    avg_p4 = await redis_client.get_avg_processing_time("tesla_p4")
    avg_3060 = await redis_client.get_avg_processing_time("rtx_3060")

    active_ids = await redis_client.get_active_jobs()
    recent_ids = await redis_client.get_recent_jobs(limit=10)

    uptime_s = time.time() - _start_time

    return {
        "uptime_seconds": round(uptime_s, 1),
        "queues": [s.model_dump() for s in queue_stats],
        "avg_processing_time_ms": {
            "tesla_p4": round(avg_p4, 1),
            "rtx_3060": round(avg_3060, 1),
        },
        "active_jobs": len(active_ids),
        "recent_jobs": recent_ids,
        "jobs_last_60s": {
            "tesla_p4": _jobs_last_minute("tesla_p4"),
            "rtx_3060": _jobs_last_minute("rtx_3060"),
            "openai": _jobs_last_minute("openai"),
        },
    }


# ══════════════════════════════════════════════════════════════════
#  GET /api/v1/health — healthcheck
# ══════════════════════════════════════════════════════════════════


async def _ping_ollama(url: str, name: str) -> dict[str, str]:
    """Pinguj Ollama server (GET /api/tags)."""
    assert _http is not None
    try:
        resp = await _http.get(f"{url}/api/tags")
        return {
            "name": name,
            "url": url,
            "status": "ok" if resp.status_code == 200 else f"http_{resp.status_code}",
        }
    except Exception as exc:
        return {"name": name, "url": url, "status": f"error: {exc}"}


@app.get("/api/v1/health")
async def health_endpoint() -> dict[str, Any]:
    """Healthcheck — Redis + oba Ollama servery + watchdog."""
    checks: dict[str, Any] = {}

    # Redis ping
    try:
        await redis_client.pool.ping()
        checks["redis"] = "ok"
    except Exception as exc:
        checks["redis"] = f"error: {exc}"

    # Ollama serwery
    p4 = await _ping_ollama(settings.tesla_p4_url, "tesla_p4")
    rtx = await _ping_ollama(settings.rtx_3060_url, "rtx_3060")
    checks["ollama"] = [p4, rtx]

    # Watchdog alive?
    checks["watchdog"] = (
        "alive" if _watchdog is not None and _watchdog.is_alive else "dead"
    )

    # Ogólny status
    redis_ok = checks["redis"] == "ok"
    gpu_ok = p4["status"] == "ok" or rtx["status"] == "ok"
    both_gpu_ok = p4["status"] == "ok" and rtx["status"] == "ok"
    watchdog_ok = checks["watchdog"] == "alive"

    if redis_ok and both_gpu_ok and watchdog_ok:
        overall = "healthy"
    elif redis_ok and gpu_ok:
        overall = "degraded"
    else:
        overall = "down"

    return {
        "status": overall,
        "uptime_seconds": round(time.time() - _start_time, 1),
        "checks": checks,
    }
