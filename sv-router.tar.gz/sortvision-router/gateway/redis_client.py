"""Async Redis wrapper — singleton z connection pool.

NIGDY nie używaj KEYS() — blokuje cały Redis!
Zamiast tego: active_jobs SET + SMEMBERS.
"""

from __future__ import annotations

import logging
import time

import redis.asyncio as aioredis

from gateway.config import settings
from gateway.schemas import QueueStats

logger = logging.getLogger(__name__)

# ── Nazwy kolejek (stałe) ─────────────────────────────────────────
QUEUE_TESLA_P4 = "queue:tesla_p4"
QUEUE_RTX_3060 = "queue:rtx_3060"
ALL_QUEUES = [QUEUE_TESLA_P4, QUEUE_RTX_3060]

# ── Klucze Redis ───────────────────────────────────────────────────
ACTIVE_JOBS_KEY = "active_jobs"


class RedisClient:
    """Singleton async Redis z connection pool."""

    _instance: RedisClient | None = None
    _pool: aioredis.Redis | None = None

    def __new__(cls) -> RedisClient:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    async def connect(self) -> None:
        """Inicjalizuj connection pool (wywoływane raz przy starcie)."""
        if self._pool is not None:
            return
        self._pool = aioredis.from_url(
            settings.redis_url,
            decode_responses=True,
            max_connections=50,
        )
        logger.info("Redis połączony: %s", settings.redis_url)

    async def close(self) -> None:
        """Zamknij pool (przy shutdownie)."""
        if self._pool is not None:
            await self._pool.aclose()
            self._pool = None
            RedisClient._instance = None

    @property
    def pool(self) -> aioredis.Redis:
        """Dostęp do puli — rzuca jeśli nie połączono."""
        if self._pool is None:
            raise RuntimeError("RedisClient.connect() nie został wywołany")
        return self._pool

    # ══════════════════════════════════════════════════════════════
    #  Kolejki jobów
    # ══════════════════════════════════════════════════════════════

    async def push_job(self, queue_name: str, job_payload_json: str) -> int:
        """Wrzuć job do kolejki (RPUSH). Zwraca nową długość kolejki."""
        return await self.pool.rpush(queue_name, job_payload_json)

    async def get_queue_length(self, queue_name: str) -> int:
        """Długość kolejki (LLEN)."""
        return await self.pool.llen(queue_name)

    # ══════════════════════════════════════════════════════════════
    #  Status jobów (Redis Hash  job:{job_id})
    # ══════════════════════════════════════════════════════════════

    async def set_job_status(
        self,
        job_id: str,
        status: str,
        *,
        progress: str | None = None,
        extra: dict | None = None,
        ttl: int | None = None,
    ) -> None:
        """Ustaw/aktualizuj status joba w hashu job:{job_id}.

        extra — dodatkowe pola do HSET (np. source, worker, queue,
                pages, created_at, timeout_at).
        """
        if ttl is None:
            ttl = settings.job_ttl_seconds

        key = f"job:{job_id}"
        mapping: dict[str, str] = {
            "status": status,
            "updated_at": str(time.time()),
        }
        if progress is not None:
            mapping["progress"] = progress
        if extra:
            mapping.update({k: str(v) for k, v in extra.items()})

        pipe = self.pool.pipeline(transaction=False)
        pipe.hset(key, mapping=mapping)
        pipe.expire(key, ttl)
        await pipe.execute()

    async def get_job_status(self, job_id: str) -> dict | None:
        """Pobierz cały hash joba. Zwraca dict lub None jeśli nie istnieje."""
        data = await self.pool.hgetall(f"job:{job_id}")
        return data if data else None

    # ══════════════════════════════════════════════════════════════
    #  Wyniki jobów
    # ══════════════════════════════════════════════════════════════

    async def set_job_result(
        self,
        job_id: str,
        text: str,
        source: str,
        processing_time_ms: int,
        *,
        status: str = "completed",
        ttl: int | None = None,
    ) -> None:
        """Zapisz wynik OCR — status completed lub fallback.

        1. HSET wynik do hasha
        2. EXPIRE job_ttl_seconds
        3. PUBLISH na kanał result_channel:{job_id}
        4. LPUSH recent_jobs (dashboard), LTRIM 0 99
        5. SREM active_jobs — usuwamy z active set!
        """
        if ttl is None:
            ttl = settings.job_ttl_seconds

        key = f"job:{job_id}"
        now = str(time.time())

        mapping: dict[str, str] = {
            "status": status,
            "text": text,
            "source": source,
            "processing_time_ms": str(processing_time_ms),
            "updated_at": now,
            "progress": "",
        }

        pipe = self.pool.pipeline(transaction=False)
        pipe.hset(key, mapping=mapping)
        pipe.expire(key, ttl)
        pipe.publish(f"result_channel:{job_id}", status)
        pipe.lpush("recent_jobs", job_id)
        pipe.ltrim("recent_jobs", 0, 99)
        pipe.srem(ACTIVE_JOBS_KEY, job_id)
        await pipe.execute()

    # ══════════════════════════════════════════════════════════════
    #  Active jobs tracking (dla Watchdoga — ZAMIAST KEYS!)
    # ══════════════════════════════════════════════════════════════

    async def add_active_job(self, job_id: str) -> None:
        """Dodaj job do zbioru aktywnych (SADD)."""
        await self.pool.sadd(ACTIVE_JOBS_KEY, job_id)

    async def remove_active_job(self, job_id: str) -> None:
        """Usuń job ze zbioru aktywnych (SREM)."""
        await self.pool.srem(ACTIVE_JOBS_KEY, job_id)

    async def get_active_jobs(self) -> set[str]:
        """Lista aktywnych jobów — watchdog iteruje po tym zamiast KEYS."""
        return await self.pool.smembers(ACTIVE_JOBS_KEY)

    # ══════════════════════════════════════════════════════════════
    #  Anulowanie
    # ══════════════════════════════════════════════════════════════

    async def mark_cancelled(self, job_id: str, ttl: int = 120) -> None:
        """Oznacz job jako anulowany (SETEX cancelled:{job_id})."""
        await self.pool.setex(f"cancelled:{job_id}", ttl, "1")

    async def is_cancelled(self, job_id: str) -> bool:
        """Sprawdź czy job został anulowany (EXISTS)."""
        return bool(await self.pool.exists(f"cancelled:{job_id}"))

    # ══════════════════════════════════════════════════════════════
    #  Metryki (EWT + dashboard)
    # ══════════════════════════════════════════════════════════════

    async def record_processing_time(self, worker_name: str, time_ms: int) -> None:
        """Zapisz czas przetwarzania do moving-average window."""
        key = f"metrics:{worker_name}"
        pipe = self.pool.pipeline(transaction=False)
        pipe.lpush(key, str(time_ms))
        pipe.ltrim(key, 0, settings.ewt_window_size - 1)
        await pipe.execute()

    async def get_avg_processing_time(self, worker_name: str) -> float:
        """Średni czas przetwarzania (ms) z ostatnich N próbek."""
        key = f"metrics:{worker_name}"
        values = await self.pool.lrange(key, 0, -1)
        if not values:
            return 0.0
        return sum(float(v) for v in values) / len(values)

    # ══════════════════════════════════════════════════════════════
    #  Statystyki dla dashboardu
    # ══════════════════════════════════════════════════════════════

    async def get_all_queue_stats(self) -> list[QueueStats]:
        """Zbierz statystyki obu kolejek — do /status i dashboardu."""
        stats: list[QueueStats] = []
        active_ids = await self.get_active_jobs()

        for q in ALL_QUEUES:
            length = await self.get_queue_length(q)
            worker_key = q.removeprefix("queue:")
            avg_ms = await self.get_avg_processing_time(worker_key)
            ewt_s = (length * avg_ms) / 1000.0 if avg_ms > 0 else 0.0

            # Policz aktywne joby przypisane do tej kolejki
            active_count = 0
            for jid in active_ids:
                job_data = await self.pool.hget(f"job:{jid}", "queue")
                if job_data == q:
                    active_count += 1

            stats.append(
                QueueStats(
                    queue_name=q,
                    length=length,
                    ewt_seconds=round(ewt_s, 2),
                    active_jobs=active_count,
                )
            )
        return stats

    async def get_recent_jobs(self, limit: int = 10) -> list[str]:
        """Ostatnie zakończone joby (do dashboardu)."""
        return await self.pool.lrange("recent_jobs", 0, limit - 1)


# ── Globalny singleton ─────────────────────────────────────────────
redis_client = RedisClient()
