"""OpenAI GPT-4o Vision fallback — httpx, bez openai SDK."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import httpx

from gateway.config import settings

logger = logging.getLogger(__name__)

_OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"

_SYSTEM_PROMPT = (
    "Jesteś OCR engine. Przepisz CAŁY tekst z dokumentu. "
    "Zachowaj formatowanie, paragrafy, nagłówki. "
    "Zwróć czysty tekst bez komentarzy."
)

_MAX_RETRIES = 3
_REQUEST_TIMEOUT = 60.0


class OpenAIFallback:
    """Fallback OCR przez OpenAI GPT-4o Vision API (httpx)."""

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Lazy-init httpx klienta z odpowiednimi headerami."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers={
                    "Authorization": f"Bearer {settings.openai_api_key}",
                    "Content-Type": "application/json",
                },
                timeout=httpx.Timeout(_REQUEST_TIMEOUT, connect=10.0),
            )
        return self._client

    async def close(self) -> None:
        """Zamknij httpx klienta (przy shutdownie)."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def process(
        self,
        doc_base64: str | list[str],
        pages: int = 1,
        filename: str | None = None,
    ) -> str:
        """Wyślij obraz(y) do GPT-4o Vision i zwróć tekst OCR.

        Args:
            doc_base64: base64 jednej strony LUB lista base64 dla wielostronicowego
            pages: liczba stron (informacyjnie)
            filename: oryginalna nazwa pliku (do logów)

        Returns:
            Rozpoznany tekst dokumentu.

        Raises:
            RuntimeError: brak API key lub wyczerpane retries.
        """
        if not settings.openai_api_key:
            raise RuntimeError("OPENAI_API_KEY nie ustawiony — fallback niemożliwy")

        # Zbuduj content z obrazami
        image_parts = self._build_image_parts(doc_base64)

        user_content: list[dict[str, Any]] = [
            {"type": "text", "text": "Przepisz tekst z tego dokumentu."},
            *image_parts,
        ]

        payload: dict[str, Any] = {
            "model": settings.openai_model,
            "max_tokens": 4096,
            "messages": [
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user_content},
            ],
        }

        # Retry z exponential backoff (rate limit / transient errors)
        last_error: Exception | None = None
        for attempt in range(1, _MAX_RETRIES + 1):
            try:
                result, elapsed_ms, usage = await self._send(payload)
                logger.info(
                    "OpenAI fallback OK: file=%s, pages=%d, time=%dms, "
                    "tokens=%s",
                    filename or "?",
                    pages,
                    elapsed_ms,
                    self._format_usage(usage),
                )
                return result

            except httpx.TimeoutException:
                last_error = TimeoutError(
                    f"OpenAI timeout ({_REQUEST_TIMEOUT}s) — próba {attempt}/{_MAX_RETRIES}"
                )
                logger.warning(str(last_error))

            except _RateLimitError as exc:
                last_error = exc
                backoff = 2**attempt
                logger.warning(
                    "OpenAI rate limit (429) — retry za %ds (próba %d/%d)",
                    backoff,
                    attempt,
                    _MAX_RETRIES,
                )
                await asyncio.sleep(backoff)

            except _APIError as exc:
                # Błędy 4xx (poza 429) nie mają sensu retry
                raise RuntimeError(f"OpenAI API error: {exc}") from exc

        raise RuntimeError(
            f"OpenAI fallback wyczerpał {_MAX_RETRIES} prób: {last_error}"
        )

    # ── Prywatne helpery ───────────────────────────────────────────

    def _build_image_parts(
        self, doc_base64: str | list[str]
    ) -> list[dict[str, Any]]:
        """Zbuduj listę image_url parts dla OpenAI API."""
        images = doc_base64 if isinstance(doc_base64, list) else [doc_base64]
        return [
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{img}",
                    "detail": "high",
                },
            }
            for img in images
        ]

    async def _send(
        self, payload: dict[str, Any]
    ) -> tuple[str, int, dict[str, Any] | None]:
        """Wyślij request do OpenAI i sparsuj odpowiedź.

        Returns:
            (tekst, elapsed_ms, usage_dict | None)
        """
        client = await self._get_client()
        t0 = time.monotonic()
        resp = await client.post(_OPENAI_CHAT_URL, json=payload)
        elapsed_ms = int((time.monotonic() - t0) * 1000)

        if resp.status_code == 429:
            raise _RateLimitError("rate limit 429")

        if resp.status_code >= 400:
            body = resp.text[:500]
            raise _APIError(f"HTTP {resp.status_code}: {body}")

        data = resp.json()
        text = data["choices"][0]["message"]["content"] or ""
        usage = data.get("usage")
        return text, elapsed_ms, usage

    @staticmethod
    def _format_usage(usage: dict[str, Any] | None) -> str:
        """Sformatuj informację o tokenach z response."""
        if not usage:
            return "brak danych"
        prompt = usage.get("prompt_tokens", "?")
        completion = usage.get("completion_tokens", "?")
        total = usage.get("total_tokens", "?")
        return f"prompt={prompt}, completion={completion}, total={total}"


# ── Wewnętrzne wyjątki ─────────────────────────────────────────────


class _RateLimitError(Exception):
    """429 — do retry z backoff."""


class _APIError(Exception):
    """4xx/5xx inny niż 429 — nie retryuj."""


# ── Globalny singleton ─────────────────────────────────────────────
openai_fallback = OpenAIFallback()
