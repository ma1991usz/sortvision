"""Watchdog — klasa skanująca active_jobs, odpala fallback przy timeout."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import TYPE_CHECKING

import aiofiles

if TYPE_CHECKING:
    from gateway.config import Settings
    from gateway.fallback import OpenAIFallback
    from gateway.redis_client import RedisClient

logger = logging.getLogger(__name__)

_INTERVAL_S = 5  # Co ile sekund skanować aktywne joby


class Watchdog:
    """Skanuje active_jobs co 5 s — timeout → OpenAI fallback."""

    def __init__(
        self,
        redis: RedisClient,
        fallback: OpenAIFallback,
        settings: Settings,
    ) -> None:
        self._redis = redis
        self._fallback = fallback
        self._settings = settings
        self._running = False

    @property
    def is_alive(self) -> bool:
        return self._running

    # ── Główna pętla ──────────────────────────────────────────────

    async def run(self) -> None:
        """Główna pętla — co _INTERVAL_S sekund skanuj aktywne joby.

        NIE używa KEYS() — iteruje po SMEMBERS "active_jobs".
        """
        self._running = True
        logger.info("Watchdog uruchomiony — interwał %ds", _INTERVAL_S)

        while self._running:
            try:
                await self._check_timeouts()
            except Exception as exc:
                logger.error("Watchdog error: %s", exc)

            await asyncio.sleep(_INTERVAL_S)

        logger.info("Watchdog zakończony")

    def stop(self) -> None:
        """Zatrzymaj pętlę po bieżącym cyklu."""
        self._running = False

    # ── Skan timeoutów ────────────────────────────────────────────

    async def _check_timeouts(self) -> None:
        """Przejdź przez active_jobs — timeouty → fallback."""
        active_ids = await self._redis.get_active_jobs()
        now = time.time()

        for job_id in active_ids:
            job_data = await self._redis.get_job_status(job_id)

            if not job_data:
                # Orphan w secie — wyczyść
                await self._redis.remove_active_job(job_id)
                continue

            status = job_data.get("status", "")
            if status not in ("queued", "processing"):
                continue

            timeout_at = float(job_data.get("timeout_at", "0"))
            if timeout_at > 0 and now > timeout_at:
                # Timeout! Odpali fallback w osobnym tasku
                asyncio.create_task(self._handle_timed_out_job(job_id, job_data))

    # ── Obsługa pojedynczego timeout joba ─────────────────────────

    async def _handle_timed_out_job(
        self, job_id: str, job_data: dict[str, str]
    ) -> None:
        """Obsłuż job który przekroczył timeout — fallback OpenAI."""
        doc_path = job_data.get("doc_path", "")
        filename = job_data.get("filename", "?")
        pages = int(job_data.get("pages", "1"))

        logger.warning(
            "Watchdog: job %s timeout — odpaliam OpenAI fallback (file=%s, pages=%d)",
            job_id, filename, pages,
        )

        # 1. Oznacz jako anulowany (worker to sprawdzi i przerwie)
        await self._redis.mark_cancelled(job_id)

        # 2. Wczytaj base64 z dysku (async!)
        if not doc_path or not os.path.isfile(doc_path):
            logger.error(
                "Watchdog: brak pliku %s dla job %s — fail", doc_path, job_id
            )
            await self._redis.set_job_status(
                job_id, "failed",
                extra={"text": f"Plik base64 nie znaleziony: {doc_path}"},
            )
            await self._redis.remove_active_job(job_id)
            return

        try:
            async with aiofiles.open(doc_path, "r") as f:
                raw = await f.read()
            # Plik może być JSON-array lub surowy base64
            try:
                doc_base64 = json.loads(raw)
            except json.JSONDecodeError:
                doc_base64 = raw
        except Exception as exc:
            logger.error("Watchdog: błąd odczytu %s: %s", doc_path, exc)
            await self._redis.set_job_status(
                job_id, "failed",
                extra={"text": f"Błąd odczytu pliku: {exc}"},
            )
            await self._redis.remove_active_job(job_id)
            return

        # 3. Odpali fallback OpenAI
        t0 = time.monotonic()
        try:
            text = await self._fallback.process(
                doc_base64=doc_base64,
                pages=pages,
                filename=filename,
            )
            elapsed_ms = int((time.monotonic() - t0) * 1000)

            # 4. Zapisz wynik w Redis (set_job_result robi SREM z active_jobs)
            await self._redis.set_job_result(
                job_id,
                status="fallback",
                text=text,
                source="openai",
                processing_time_ms=elapsed_ms,
            )

            logger.info(
                "Watchdog: job %s fallback OK — %dms, %d znaków",
                job_id, elapsed_ms, len(text),
            )

        except Exception as exc:
            elapsed_ms = int((time.monotonic() - t0) * 1000)
            logger.error(
                "Watchdog: job %s fallback FAILED po %dms: %s",
                job_id, elapsed_ms, exc,
            )
            await self._redis.set_job_status(
                job_id, "failed",
                extra={"text": f"GPU timeout + OpenAI fallback error: {exc}"},
            )
            await self._redis.remove_active_job(job_id)

        # 5. Usuń plik base64 z dysku
        try:
            os.remove(doc_path)
        except OSError:
            pass
