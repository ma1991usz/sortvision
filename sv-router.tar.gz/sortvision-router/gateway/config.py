"""Konfiguracja gateway'a — ładowana z env vars z prefixem SV_."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Ustawienia gateway'a SortVision OCR Router."""

    # ── Redis ──────────────────────────────────────────────────────
    redis_url: str = "redis://localhost:6379/0"

    # ── Ollama GPU endpoints ───────────────────────────────────────
    tesla_p4_url: str = "http://192.168.25.37:11434"
    rtx_3060_url: str = "http://192.168.25.176:11434"

    # ── OpenAI fallback ────────────────────────────────────────────
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"

    # ── Dynamic timeout ────────────────────────────────────────────
    base_timeout_seconds: int = 20
    """Bazowy timeout niezależny od stron."""

    per_page_timeout_seconds: int = 25
    """Dodatkowy timeout za każdą stronę.

    Formuła: base + pages × per_page.
    Np. 10 stron = 20 + 250 = 270s."""

    # ── Routing — progi dla Tesla P4 ──────────────────────────────
    max_pages_p4: int = 2
    """Dokumenty z więcej niż tyle stron → RTX 3060."""

    max_resolution_p4: int = 3_000_000
    """Obrazy powyżej 3 MP (width×height) → RTX 3060."""

    # ── EWT (Estimated Wait Time) ─────────────────────────────────
    ewt_window_size: int = 20
    """Ile ostatnich czasów przetwarzania brać do moving average."""

    # ── Job lifecycle ──────────────────────────────────────────────
    job_poll_interval_hint: int = 3
    """Sugerowany interwał pollingu dla klienta (sekundy)."""

    job_ttl_seconds: int = 3600
    """Jak długo trzymać wynik joba w Redis po zakończeniu."""

    jobs_disk_path: str = "/opt/models/jobs"
    """Gdzie zapisywać base64 na dysk (backup dla watchdoga)."""

    model_config = {"env_prefix": "SV_"}


settings = Settings()
